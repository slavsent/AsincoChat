Logs package
=================================================

Пакет, содержащий конфигурации для логирования работы клиентского и серверного модулей.

* Скрипт config_client_log.py содержит конфигурацию клиентского логгера.
* Скрипт config_server_log.py содержит конфигурацию серверного логгера.

Submodules
----------

log.client\_log\_config module
------------------------------

.. automodule:: log.client_log_config
   :members:
   :undoc-members:
   :show-inheritance:

log.server\_log\_config module
------------------------------

.. automodule:: log.server_log_config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: log
   :members:
   :undoc-members:
   :show-inheritance:
