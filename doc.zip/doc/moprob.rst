moprob module
=============

.. automodule:: mypackage.moprob
        :members: